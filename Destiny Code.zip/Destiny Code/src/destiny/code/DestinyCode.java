/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package destiny.code;

/**
 *
 * @author Joseph
 */
public class DestinyCode {

    
    public static void main(String[] args) {
       KillEnemyTarget killTarget=new KillEnemyTarget("Kill Enemy Target", "Moon", 120, "A",300,100);
       GatherMaterialsFromDefeatedEnemies killEnemies= new GatherMaterialsFromDefeatedEnemies("Kill Enemies and retrive their materials", "Moon", 120, "B", 300,100);
       ScanObject scan=new ScanObject("Scan Object", "Moon", 120, "C",300,100);
       SurveyArea survey=new SurveyArea("Survey Area", "Moon",120,"D",300,100);
       EliminateEnemies clearArea=new EliminateEnemies("Elimiate Enemies","Moon", 120,"E",300,100);
       EnergizeSparrow sparrowMission=new EnergizeSparrow("Energize Sparrow","Moon",120,"F",300,100);
       
       
           
           
       
    }

}
